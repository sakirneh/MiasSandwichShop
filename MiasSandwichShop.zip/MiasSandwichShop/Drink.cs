﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiasSandwichShop
{
    public class Drink : Product
    {

        List<string> lines = new List<string>();
        List<Product> products = new List<Product>();
        List<string> OutContents = new List<string>();


        string filePath = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\shop data\Drink List.txt";


        public Drink()
        {

        }


        public void GetAllDrinksFromFile()
        {
            lines = File.ReadAllLines(filePath).ToList();

            foreach (string line in lines)
            {
                string[] items = line.Split(',');
                Product product = new Product(items[0], items[1], items[2]);
                products.Add(product);

            }
        }
        public List<Product> GetAllDrinks()
        {
            return products;
        }
    }
}
