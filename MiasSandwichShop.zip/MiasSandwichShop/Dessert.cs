﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiasSandwichShop
{
    public class Dessert : Product
    {
        List<string> lines = new List<string>();
        List<Product> products = new List<Product>();
        List<string> OutContents = new List<string>();


        string filePath = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\shop data\Dessert List.txt";


        public Dessert()
        {

        }


        public void GetAllDessertsFromFile()
        {
            lines = File.ReadAllLines(filePath).ToList();

            foreach (string line in lines)
            {
                string[] items = line.Split(',');
                Product product = new Product(items[0], items[1], items[2]);
                products.Add(product);

            }
        }
        public List<Product> GetAllDesserts()
        {
            return products;
        }
    }
}
