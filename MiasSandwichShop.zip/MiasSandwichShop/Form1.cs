namespace MiasSandwichShop
{
    public partial class Form1 : Form
    {

        Cart cart;

        SandWich sndWich;
        Drink drink;
        Dessert dessert;


        BindingSource cartBindingSource;
        List<Product> products;// create new product list
        List<Product> CartProductList;
        Product product;

        public const int cartIndex = 3;



        public Form1()
        {
            InitializeComponent();

            sndWich = new SandWich();
            sndWich.GetAllSandwichesFromFile();

            drink = new Drink();
            drink.GetAllDrinksFromFile();

            dessert = new Dessert();
            dessert.GetAllDessertsFromFile();

            cartBindingSource = new BindingSource();
            cart = new Cart();

            cartBindingSource.DataSource = cart.GetAllProducts();

            sandwichListBox.DataSource = cartBindingSource; // sandwich list box connected to cart.
            sandwichListBox.DisplayMember = ToString();

            drinkListBox.DataSource = cartBindingSource; // drinks list box connected to cart class/ object.
            drinkListBox.DisplayMember = ToString();

            DessertListBox.DataSource = cartBindingSource;
            DessertListBox.DisplayMember = ToString();

            FinalCartListBox.DataSource = cartBindingSource;
            FinalCartListBox.DisplayMember = ToString();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Size = new Size(800, 600); // sets form size to the same as the previous form.
            FormBorderStyle = FormBorderStyle.Fixed3D;
            CenterToScreen();

            this.foodTab.SelectedIndex = 0;

            LoadFirstTabOnFormLoad();
        }





        private void FillListBox(string _path, ListView _listView, int index)
        {
            //instantiate new object of ImageList type, set images to 100px by 100px.
            ImageList images = new ImageList();
            images.ImageSize = new Size(200, 200);


            //load images from file path given.
            String[] paths = { };
            paths = Directory.GetFiles(_path);

            try
            {
                foreach (string path in paths)
                {
                    images.Images.Add(Image.FromFile(path));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            _listView.SmallImageList = images;

            for (int i = 0; i < index; i++)
            {
                _listView.Items.Add(products[i].productName + products[i].price, i);
            }

        }





        private void BtnRemoveItemFromLSTbox_Click(object sender, EventArgs e)
        {
            CartProductList = cart.GetAllProducts();
            try
            {
                product = CartProductList[CartProductList.Count - 1];
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show($"Your Cart is already Empty!");
                Console.WriteLine(e);
            }
            cart.RemoveFromCart(product);
            cartBindingSource.ResetBindings(false);
            lblTotal.Text = "Total: �" + cart.Total().ToString();
        }


        private void sndwichListViewClick(object sender, EventArgs e)
        {
            String Selected = sandwichListView.SelectedItems[0].SubItems[0].Text;


            for (int i = 0; i < products.Count; i++)
            {
                string temp = products[i].productName + products[i].price;
                if (temp == Selected)
                {
                    product = products[i];
                    cart.AddToCart(product);

                    cartBindingSource.ResetBindings(false);
                    lblTotal.Text = "Total: �" + cart.Total().ToString();
                    break;
                }
            }
        }

        private void sndwichTabSelected(object sender, TabControlEventArgs e)
        {

            int tabSelected = foodTab.SelectedIndex;

            lblTotal.Text = "Total: �" + cart.Total().ToString();
            lblTotal2.Text = "Total: �" + cart.Total().ToString();
            lblTotal3.Text = "Total: �" + cart.Total().ToString();

            //clear the images displayed on the form otherwise they will load again once switched back to the same tab.
            sandwichListView.Clear();
            DrinkListView.Clear();
            DessertListView.Clear();

            DrinkListView.View = View.Details;
            sandwichListView.View = View.Details;
            DessertListView.View = View.Details;


            //make columns for the listbox view.
            sandwichListView.Columns.Add("Sandwich Options", 200, HorizontalAlignment.Left);
            sandwichListView.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);

            DrinkListView.Columns.Add("Drink Options", 200, HorizontalAlignment.Left);
            DrinkListView.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);

            DessertListView.Columns.Add("Dessert Options", 200, HorizontalAlignment.Left);
            DessertListView.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);

            string path1 = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\Images\sandwiches"; //using string literals for paths to files
            string path2 = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\Images\Drinks";
            string path3 = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\Images\Desserts";



            int index;
            switch (tabSelected)
            {
                case 0:
                    products = sndWich.GetAllSandwiches();
                    index = sndWich.GetAllSandwiches().Count;
                    FillListBox(path1, sandwichListView, index);
                    break;
                case 1:
                    products = drink.GetAllDrinks();
                    index = drink.GetAllDrinks().Count;
                    FillListBox(path2, DrinkListView, index);
                    break;
                case 2:
                    products = dessert.GetAllDesserts();
                    index = dessert.GetAllDesserts().Count;
                    FillListBox(path3, DessertListView, index);
                    break;
                case 3:
                default:
                    break;
            }


        }

        private void DrinkListViewClick(object sender, EventArgs e)
        {
            String Selected = DrinkListView.SelectedItems[0].SubItems[0].Text;


            for (int i = 0; i < products.Count; i++)
            {
                string temp = products[i].productName + products[i].price;
                if (temp == Selected)
                {
                    product = products[i];
                    cart.AddToCart(product);

                    cartBindingSource.ResetBindings(false);
                    lblTotal2.Text = "Total: �" + cart.Total().ToString();
                    break;
                }
            }
        }

        private void DessertsListViewClick(object sender, EventArgs e)
        {
            String Selected = DessertListView.SelectedItems[0].SubItems[0].Text;


            for (int i = 0; i < products.Count; i++)
            {
                string temp = products[i].productName + products[i].price;
                if (temp == Selected)
                {
                    product = products[i];
                    cart.AddToCart(product);

                    cartBindingSource.ResetBindings(false);
                    lblTotal3.Text = "Total: �" + cart.Total().ToString();
                    break;
                }
            }
        }

        private void BTNremoveItem_Click(object sender, EventArgs e)
        {
            CartProductList = cart.GetAllProducts();
            try
            {
                product = CartProductList[CartProductList.Count - 1];
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show($"Your Cart is already Empty!");
                Console.WriteLine(e);
            }
            cart.RemoveFromCart(product);
            cartBindingSource.ResetBindings(false);
            lblTotal2.Text = "Total: �" + cart.Total().ToString();
        }

        private void BTNremoveLastItem2_Click(object sender, EventArgs e)
        {
            CartProductList = cart.GetAllProducts();
            try
            {
                product = CartProductList[CartProductList.Count - 1];
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show($"Your Cart is already Empty!");
                Console.WriteLine(e);
            }
            cart.RemoveFromCart(product);
            cartBindingSource.ResetBindings(false);
            lblTotal3.Text = "Total: �" + cart.Total().ToString();
        }

        private void goToCart_Click(object sender, EventArgs e)
        {
            this.foodTab.SelectedIndex = cartIndex;
            lblTotal4.Text = "Total: �" + cart.Total().ToString();
        }

        private void goToCart2_Click(object sender, EventArgs e)
        {
            this.foodTab.SelectedIndex = cartIndex;
            lblTotal4.Text = "Total: �" + cart.Total().ToString();
        }

        private void goToCart3_Click(object sender, EventArgs e)
        {
            this.foodTab.SelectedIndex = cartIndex;
            lblTotal4.Text = "Total: �" + cart.Total().ToString();
        }

        private void PrintOrder_Click(object sender, EventArgs e)
        {
            cart.WriteContents();
        }

        private void ClearCartOrderBTN_Click(object sender, EventArgs e)
        {
            ClearListBoxes();

            foreach (Product item in cart.GetAllProducts().ToList())
            {
                cart.RemoveFromCart(item);
            }

            SetDataSources();
        }

        private void SetDataSources()
        {
            FinalCartListBox.DataSource = cartBindingSource;
            sandwichListBox.DataSource = cartBindingSource;
            drinkListBox.DataSource = cartBindingSource;
            DessertListBox.DataSource = cartBindingSource;
        }

        private void ClearListBoxes()
        {
            FinalCartListBox.DataSource = null;
            FinalCartListBox.Items.Clear();
            lblTotal4.Text = "Total:";

            sandwichListBox.DataSource = null;
            sandwichListBox.Items.Clear();

            drinkListBox.DataSource = null;
            drinkListBox.Items.Clear();

            DessertListBox.DataSource = null;
            DessertListBox.Items.Clear();
        }

        private void LoadFirstTabOnFormLoad()
        {
            int index = sndWich.GetAllSandwiches().Count;
            sandwichListView.View = View.Details;



            //make columns for the listbox view.
            sandwichListView.Columns.Add("Sandwich Options", 200, HorizontalAlignment.Left);
            sandwichListView.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
            string path1 = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\Images\sandwiches";
            products = sndWich.GetAllSandwiches();
            FillListBox(path1, sandwichListView, index);
        }
    }
}