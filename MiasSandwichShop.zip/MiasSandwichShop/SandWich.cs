﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiasSandwichShop
{
    public class SandWich : Product
    {
        string filePath = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\shop data\Sandwich List.txt";

        List<string> lines = new List<string>();
        List<Product> products = new List<Product>();
        List<string> OutContents = new List<string>();  
        

        public SandWich()
        {

        }

        public void GetAllSandwichesFromFile()
        {
            lines = File.ReadAllLines(filePath).ToList();

            foreach (string line in lines)
            {
                string[] items = line.Split(',');
                Product product = new Product(items[0], items[1], items[2]);
                products.Add(product);

            }
        }
        public List<Product> GetAllSandwiches()
        {
            return products;
        }

        public void WriteContents()
        {
            foreach (Product p in products)
            {
                OutContents.Add(p.ToString());
                string OutFile = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\shop data\Outfile.txt";
                File.WriteAllLines(OutFile, OutContents);
            }
        }
    }
}
