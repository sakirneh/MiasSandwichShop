﻿using MiasSandwichShop;
using System;

public class Cart
{
	private List<Product> products = new List<Product>();
	private List<string> OutContents = new List<string>();
	private decimal total;

	public Cart()
	{
		
	}

	public void AddToCart(Product product)
	{
		products.Add(product);
	}

	public void RemoveFromCart(Product product)
	{
		products.Remove(product);
	}


    public List<Product> GetAllProducts() // example of abstraction - hiding the list of products in a method rather than manually getting and setting it.
	{
		return products;
	}

	public decimal Total() // method for adding the price of each product in a list into a single variable of type double.
	{
		total = 0.0m;

		foreach (var item in products)
		{
			total = total + Convert.ToDecimal(item.price);
		}
		return total;
	}

    public void WriteContents()
    {
        string OutFile = @"H:\Unit 16 OOP Jhora\kiosk project\MiasSandwichShop\shop data\Receipt.txt";
        foreach (Product p in products)
        {
			
            OutContents.Add(p.ToString());
            File.WriteAllLines(OutFile, OutContents);
        }
		decimal tempTotal = Total() * 1.2m;
		OutContents.Add("£" +Total().ToString());
		OutContents.Add($"VAT Total:{tempTotal.ToString()}\n"); 
        File.WriteAllLines(OutFile, OutContents);

		MessageBox.Show($"Total:£{Total().ToString()}\nVAT Total:£{tempTotal.ToString()}");
    }


}
