﻿namespace MiasSandwichShop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            foodTab = new TabControl();
            FoodPage = new TabPage();
            goToCart = new Button();
            lblTotal = new Label();
            BtnRemoveItemFromLSTbox = new Button();
            orderLabel = new Label();
            SandwichGroupBox = new GroupBox();
            sandwichListView = new ListView();
            sandwichListBox = new ListBox();
            DrinksPage = new TabPage();
            goToCart2 = new Button();
            DrinkListView = new ListView();
            lblTotal2 = new Label();
            BTNremoveItem = new Button();
            label3 = new Label();
            drinkListBox = new ListBox();
            DesertPage = new TabPage();
            goToCart3 = new Button();
            DessertListView = new ListView();
            lblTotal3 = new Label();
            BTNremoveLastItem2 = new Button();
            label4 = new Label();
            DessertListBox = new ListBox();
            CartPage = new TabPage();
            CartGroupBox = new GroupBox();
            ClearCartOrderBTN = new Button();
            lblTotal4 = new Label();
            PrintOrder = new Button();
            label1 = new Label();
            FinalCartListBox = new ListBox();
            foodTab.SuspendLayout();
            FoodPage.SuspendLayout();
            SandwichGroupBox.SuspendLayout();
            DrinksPage.SuspendLayout();
            DesertPage.SuspendLayout();
            CartPage.SuspendLayout();
            CartGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // foodTab
            // 
            foodTab.AllowDrop = true;
            foodTab.Controls.Add(FoodPage);
            foodTab.Controls.Add(DrinksPage);
            foodTab.Controls.Add(DesertPage);
            foodTab.Controls.Add(CartPage);
            foodTab.Location = new Point(0, -1);
            foodTab.Name = "foodTab";
            foodTab.SelectedIndex = 0;
            foodTab.Size = new Size(784, 560);
            foodTab.TabIndex = 0;
            foodTab.Selected += sndwichTabSelected;
            // 
            // FoodPage
            // 
            FoodPage.AllowDrop = true;
            FoodPage.AutoScroll = true;
            FoodPage.Controls.Add(goToCart);
            FoodPage.Controls.Add(lblTotal);
            FoodPage.Controls.Add(BtnRemoveItemFromLSTbox);
            FoodPage.Controls.Add(orderLabel);
            FoodPage.Controls.Add(SandwichGroupBox);
            FoodPage.Controls.Add(sandwichListBox);
            FoodPage.Location = new Point(4, 24);
            FoodPage.Name = "FoodPage";
            FoodPage.Padding = new Padding(3);
            FoodPage.Size = new Size(776, 532);
            FoodPage.TabIndex = 0;
            FoodPage.Text = "Sandwiches";
            FoodPage.UseVisualStyleBackColor = true;
            // 
            // goToCart
            // 
            goToCart.Location = new Point(556, 488);
            goToCart.Name = "goToCart";
            goToCart.Size = new Size(211, 38);
            goToCart.TabIndex = 16;
            goToCart.Text = "Go To Cart";
            goToCart.UseVisualStyleBackColor = true;
            goToCart.Click += goToCart_Click;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal.Location = new Point(557, 402);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(92, 40);
            lblTotal.TabIndex = 4;
            lblTotal.Text = "Total: ";
            // 
            // BtnRemoveItemFromLSTbox
            // 
            BtnRemoveItemFromLSTbox.Location = new Point(556, 445);
            BtnRemoveItemFromLSTbox.Name = "BtnRemoveItemFromLSTbox";
            BtnRemoveItemFromLSTbox.Size = new Size(211, 38);
            BtnRemoveItemFromLSTbox.TabIndex = 3;
            BtnRemoveItemFromLSTbox.Text = "Remove Last Added Item";
            BtnRemoveItemFromLSTbox.UseVisualStyleBackColor = true;
            BtnRemoveItemFromLSTbox.Click += BtnRemoveItemFromLSTbox_Click;
            // 
            // orderLabel
            // 
            orderLabel.AutoSize = true;
            orderLabel.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            orderLabel.Location = new Point(557, 15);
            orderLabel.Name = "orderLabel";
            orderLabel.Size = new Size(216, 32);
            orderLabel.TabIndex = 2;
            orderLabel.Text = "Your Current Order";
            // 
            // SandwichGroupBox
            // 
            SandwichGroupBox.Controls.Add(sandwichListView);
            SandwichGroupBox.Location = new Point(3, 0);
            SandwichGroupBox.Name = "SandwichGroupBox";
            SandwichGroupBox.Size = new Size(547, 514);
            SandwichGroupBox.TabIndex = 1;
            SandwichGroupBox.TabStop = false;
            // 
            // sandwichListView
            // 
            sandwichListView.Alignment = ListViewAlignment.SnapToGrid;
            sandwichListView.Location = new Point(3, 6);
            sandwichListView.Name = "sandwichListView";
            sandwichListView.Size = new Size(538, 505);
            sandwichListView.TabIndex = 0;
            sandwichListView.UseCompatibleStateImageBehavior = false;
            sandwichListView.Click += sndwichListViewClick;
            // 
            // sandwichListBox
            // 
            sandwichListBox.FormattingEnabled = true;
            sandwichListBox.ItemHeight = 15;
            sandwichListBox.Location = new Point(556, 50);
            sandwichListBox.Name = "sandwichListBox";
            sandwichListBox.Size = new Size(214, 349);
            sandwichListBox.TabIndex = 0;
            // 
            // DrinksPage
            // 
            DrinksPage.Controls.Add(goToCart2);
            DrinksPage.Controls.Add(DrinkListView);
            DrinksPage.Controls.Add(lblTotal2);
            DrinksPage.Controls.Add(BTNremoveItem);
            DrinksPage.Controls.Add(label3);
            DrinksPage.Controls.Add(drinkListBox);
            DrinksPage.Location = new Point(4, 24);
            DrinksPage.Name = "DrinksPage";
            DrinksPage.Padding = new Padding(3);
            DrinksPage.Size = new Size(776, 532);
            DrinksPage.TabIndex = 1;
            DrinksPage.Text = "Drinks";
            DrinksPage.UseVisualStyleBackColor = true;
            // 
            // goToCart2
            // 
            goToCart2.Location = new Point(557, 488);
            goToCart2.Name = "goToCart2";
            goToCart2.Size = new Size(211, 38);
            goToCart2.TabIndex = 16;
            goToCart2.Text = "Go To Cart";
            goToCart2.UseVisualStyleBackColor = true;
            goToCart2.Click += goToCart2_Click;
            // 
            // DrinkListView
            // 
            DrinkListView.Alignment = ListViewAlignment.SnapToGrid;
            DrinkListView.Location = new Point(3, 8);
            DrinkListView.Name = "DrinkListView";
            DrinkListView.Size = new Size(540, 511);
            DrinkListView.TabIndex = 5;
            DrinkListView.UseCompatibleStateImageBehavior = false;
            DrinkListView.Click += DrinkListViewClick;
            // 
            // lblTotal2
            // 
            lblTotal2.AutoSize = true;
            lblTotal2.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal2.Location = new Point(558, 401);
            lblTotal2.Name = "lblTotal2";
            lblTotal2.Size = new Size(92, 40);
            lblTotal2.TabIndex = 9;
            lblTotal2.Text = "Total: ";
            // 
            // BTNremoveItem
            // 
            BTNremoveItem.Location = new Point(557, 444);
            BTNremoveItem.Name = "BTNremoveItem";
            BTNremoveItem.Size = new Size(211, 38);
            BTNremoveItem.TabIndex = 8;
            BTNremoveItem.Text = "Remove Last Added Item";
            BTNremoveItem.UseVisualStyleBackColor = true;
            BTNremoveItem.Click += BTNremoveItem_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(558, 14);
            label3.Name = "label3";
            label3.Size = new Size(216, 32);
            label3.TabIndex = 7;
            label3.Text = "Your Current Order";
            // 
            // drinkListBox
            // 
            drinkListBox.FormattingEnabled = true;
            drinkListBox.ItemHeight = 15;
            drinkListBox.Location = new Point(557, 49);
            drinkListBox.Name = "drinkListBox";
            drinkListBox.Size = new Size(214, 349);
            drinkListBox.TabIndex = 6;
            // 
            // DesertPage
            // 
            DesertPage.Controls.Add(goToCart3);
            DesertPage.Controls.Add(DessertListView);
            DesertPage.Controls.Add(lblTotal3);
            DesertPage.Controls.Add(BTNremoveLastItem2);
            DesertPage.Controls.Add(label4);
            DesertPage.Controls.Add(DessertListBox);
            DesertPage.Location = new Point(4, 24);
            DesertPage.Name = "DesertPage";
            DesertPage.Padding = new Padding(3);
            DesertPage.Size = new Size(776, 532);
            DesertPage.TabIndex = 2;
            DesertPage.Text = "Deserts";
            DesertPage.UseVisualStyleBackColor = true;
            // 
            // goToCart3
            // 
            goToCart3.Location = new Point(557, 481);
            goToCart3.Name = "goToCart3";
            goToCart3.Size = new Size(211, 38);
            goToCart3.TabIndex = 15;
            goToCart3.Text = "Go To Cart";
            goToCart3.UseVisualStyleBackColor = true;
            goToCart3.Click += goToCart3_Click;
            // 
            // DessertListView
            // 
            DessertListView.Alignment = ListViewAlignment.SnapToGrid;
            DessertListView.Location = new Point(3, 8);
            DessertListView.Name = "DessertListView";
            DessertListView.Size = new Size(540, 511);
            DessertListView.TabIndex = 10;
            DessertListView.UseCompatibleStateImageBehavior = false;
            DessertListView.Click += DessertsListViewClick;
            // 
            // lblTotal3
            // 
            lblTotal3.AutoSize = true;
            lblTotal3.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal3.Location = new Point(558, 401);
            lblTotal3.Name = "lblTotal3";
            lblTotal3.Size = new Size(92, 40);
            lblTotal3.TabIndex = 14;
            lblTotal3.Text = "Total: ";
            // 
            // BTNremoveLastItem2
            // 
            BTNremoveLastItem2.Location = new Point(557, 440);
            BTNremoveLastItem2.Name = "BTNremoveLastItem2";
            BTNremoveLastItem2.Size = new Size(211, 38);
            BTNremoveLastItem2.TabIndex = 13;
            BTNremoveLastItem2.Text = "Remove Last Added Item";
            BTNremoveLastItem2.UseVisualStyleBackColor = true;
            BTNremoveLastItem2.Click += BTNremoveLastItem2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(558, 14);
            label4.Name = "label4";
            label4.Size = new Size(216, 32);
            label4.TabIndex = 12;
            label4.Text = "Your Current Order";
            // 
            // DessertListBox
            // 
            DessertListBox.FormattingEnabled = true;
            DessertListBox.ItemHeight = 15;
            DessertListBox.Location = new Point(557, 49);
            DessertListBox.Name = "DessertListBox";
            DessertListBox.Size = new Size(214, 349);
            DessertListBox.TabIndex = 11;
            // 
            // CartPage
            // 
            CartPage.Controls.Add(CartGroupBox);
            CartPage.Location = new Point(4, 24);
            CartPage.Name = "CartPage";
            CartPage.Size = new Size(776, 532);
            CartPage.TabIndex = 3;
            CartPage.Text = "Cart";
            CartPage.UseVisualStyleBackColor = true;
            // 
            // CartGroupBox
            // 
            CartGroupBox.Controls.Add(ClearCartOrderBTN);
            CartGroupBox.Controls.Add(lblTotal4);
            CartGroupBox.Controls.Add(PrintOrder);
            CartGroupBox.Controls.Add(label1);
            CartGroupBox.Controls.Add(FinalCartListBox);
            CartGroupBox.Location = new Point(2, 0);
            CartGroupBox.Name = "CartGroupBox";
            CartGroupBox.Size = new Size(774, 532);
            CartGroupBox.TabIndex = 0;
            CartGroupBox.TabStop = false;
            // 
            // ClearCartOrderBTN
            // 
            ClearCartOrderBTN.Location = new Point(8, 370);
            ClearCartOrderBTN.Name = "ClearCartOrderBTN";
            ClearCartOrderBTN.Size = new Size(188, 61);
            ClearCartOrderBTN.TabIndex = 4;
            ClearCartOrderBTN.Text = "Clear Order";
            ClearCartOrderBTN.UseVisualStyleBackColor = true;
            ClearCartOrderBTN.Click += ClearCartOrderBTN_Click;
            // 
            // lblTotal4
            // 
            lblTotal4.AutoSize = true;
            lblTotal4.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal4.Location = new Point(258, 10);
            lblTotal4.Name = "lblTotal4";
            lblTotal4.Size = new Size(104, 45);
            lblTotal4.TabIndex = 3;
            lblTotal4.Text = "Total: ";
            // 
            // PrintOrder
            // 
            PrintOrder.Location = new Point(6, 308);
            PrintOrder.Name = "PrintOrder";
            PrintOrder.Size = new Size(190, 60);
            PrintOrder.TabIndex = 2;
            PrintOrder.Text = "Print Order";
            PrintOrder.UseVisualStyleBackColor = true;
            PrintOrder.Click += PrintOrder_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(6, 10);
            label1.Name = "label1";
            label1.Size = new Size(246, 45);
            label1.TabIndex = 1;
            label1.Text = "Your Final Items";
            // 
            // FinalCartListBox
            // 
            FinalCartListBox.FormattingEnabled = true;
            FinalCartListBox.ItemHeight = 15;
            FinalCartListBox.Location = new Point(6, 58);
            FinalCartListBox.Name = "FinalCartListBox";
            FinalCartListBox.Size = new Size(760, 244);
            FinalCartListBox.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(784, 561);
            Controls.Add(foodTab);
            Name = "Form1";
            Text = "Mia's Sandwich Shop";
            Load += Form1_Load;
            foodTab.ResumeLayout(false);
            FoodPage.ResumeLayout(false);
            FoodPage.PerformLayout();
            SandwichGroupBox.ResumeLayout(false);
            DrinksPage.ResumeLayout(false);
            DrinksPage.PerformLayout();
            DesertPage.ResumeLayout(false);
            DesertPage.PerformLayout();
            CartPage.ResumeLayout(false);
            CartGroupBox.ResumeLayout(false);
            CartGroupBox.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl foodTab;
        private TabPage FoodPage;
        private TabPage DrinksPage;
        private TabPage DesertPage;
        private TabPage CartPage;
        private Label orderLabel;
        private GroupBox SandwichGroupBox;
        private ListBox sandwichListBox;
        private GroupBox CartGroupBox;
        private Button PrintOrder;
        private Label label1;
        private ListBox FinalCartListBox;
        private ListView sandwichListView;
        private Button BtnRemoveItemFromLSTbox;
        private Label lblTotal;
        private ListView DrinkListView;
        private Label lblTotal2;
        private Button BTNremoveItem;
        private Label label3;
        private ListBox drinkListBox;
        private ListView DessertListView;
        private Label lblTotal3;
        private Button BTNremoveLastItem2;
        private Label label4;
        private ListBox DessertListBox;
        private Button goToCart;
        private Button goToCart2;
        private Button goToCart3;
        private Label lblTotal4;
        private Button ClearCartOrderBTN;
    }
}